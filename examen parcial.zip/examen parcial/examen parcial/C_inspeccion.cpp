#include "StdAfx.h"
#include "C_inspeccion.h"


C_inspeccion::C_inspeccion(void)
{
}
