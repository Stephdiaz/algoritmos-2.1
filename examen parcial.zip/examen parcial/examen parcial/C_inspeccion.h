#pragma once
#include "C_arreglo.h"
#include "C_medicamento.h"
#include <iostream>
using namespace std;


class C_inspeccion 
{
private:
	C_arreglo <C_medicamento> _sustancia;
public:
	C_inspeccion(void);
	bool realizardiagnostico ();

	void sustancia ( int pos, C_medicamento val);
	C_medicamento sustancia(int pos);
};

C_inspeccion::C_inspeccion()
{

}

bool C_inspeccion::realizardiagnostico ()
{
	for (int i = 0;  _sustancia.tamano() ; i++)
	{
		if (_sustancia.datos (i).nocivo())
			return true;
	}
			return false;
	
}


void  C_inspeccion::sustancia ( int pos, C_medicamento val)
{
	_sustancia.datos (pos, val);
}
C_medicamento  C_inspeccion::sustancia(int pos)
{
	 return _sustancia.datos(pos);
}