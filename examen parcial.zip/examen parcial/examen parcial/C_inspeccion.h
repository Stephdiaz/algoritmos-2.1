#pragma once
ref class C_inspeccion
{
public:
	C_inspeccion(void);
};

