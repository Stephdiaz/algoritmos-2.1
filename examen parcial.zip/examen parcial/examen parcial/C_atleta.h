#pragma once
#include "C_deporte.h"
#include "C_arreglo.h"
#include "C_inspeccion.h"
#include <iostream>
using namespace std;

class C_atleta 
{
private:
	string _cod;
	string _nombre;
	C_arreglo <C_deporte> _deportespract;
	C_arreglo <C_inspeccion> _historial;
public:
	C_atleta(void);

	void nombre (string val);
	string nombre ();

	void codigo (string val);
	string codigo ();

	void deportespract (int pos, C_deporte dep);
	C_deporte deportespract (int pos);

	int pruebapositiva();
};

	C_atleta::C_atleta()
	{
		_cod= "";
		_nombre = "";
	}


	void C_atleta::nombre (string val)
	{
		_nombre = val;
	}
	string C_atleta::nombre ()
	{
		return _nombre;
	}

	void C_atleta::codigo (string val)
	{
		_cod = val;
	}

	string C_atleta::codigo ()
	{
		return _cod;
	}

	void C_atleta::deportespract (int pos, C_deporte dep)
	{
		_deportespract.datos (pos,dep);
	}
	C_deporte C_atleta::deportespract (int pos)
	{
		return _deportespract.datos (pos);
	}

	int C_atleta::pruebapositiva()
	{
		int x = 0;
		for (int i = 0; i < _historial.tamano();i++)
		{
			if (_historial.datos (i).realizardiagnostico())
				x++;
		}
		return x;
	}