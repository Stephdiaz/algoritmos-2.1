#pragma once
#include <string>
#include "C_arreglo.h"
#include <msclr\marshal_cppstd.h>
using namespace System;
using namespace System::Windows::Forms;
 class INTERFAZ
{
private:
	C_arreglo <C_deporte>  _deportes;
	C_arreglo <C_atleta>  _atletas;
public:
	INTERFAZ(void);
	void nuevodeporte (TextBox ^ nombre);
	void insertardeporte (DataGridView ^ tab);
};
 INTERFAZ::INTERFAZ(){}

	void INTERFAZ::nuevodeporte (TextBox ^ val)
	 {
		 string nombre = msclr::interop::marshal_as<std:: string >(val->Text);
		 int nuevodep = _deportes.tamano();

		C_deporte aux;
		aux.nombre (nombre);
		_deporte.datos(nuevodep, aux);
		_deporte.tamano (nuevodep + 1);

	 }
	 
	void INTERFAZ::insertardeporte (DataGridView ^ tab)
	{
		tab -> ColumnCount = 1;
		tab-> Column [0] -> Name = "Nombre de los deportes";
		tab ->RowCount = deportes.tamano();
		for (int i=0; i<_deporte.tamano(); i++)
		{
			string auxNombre = _deportes.Datos(i).Nombre();
			tab->Rows[i]->Cells[0]->Value = gcnew String(auxNombre.c_str());

	}
	}