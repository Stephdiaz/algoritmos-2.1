#include "StdAfx.h"
#include "C_medicamento.h"


C_medicamento::C_medicamento(void)
{
}
