#pragma once

const int MAX = 100;
template <class T>
class C_arreglo
{
private:

	T vector [MAX];
	int _tam;

public:
	C_arreglo(void);

	void datos (int pos, T val);
	T datos(int);

	void objeto (C_arreglo<T> obj );
	C_arreglo <T> objeto ();

	void tamano(int val);
	int tamano ();
};


template <class T>
C_arreglo<T>::C_arreglo()
{
	_tam=0;
}


template <class T>
void C_arreglo<T>::datos (int pos, T val)
{
	vector[pos] = val;
}

template <class T>
T C_arreglo<T>::datos  (int pos)
{
 return vector[pos];
}



template <class T>
void C_arreglo<T>::objeto (C_arreglo<T>  obj)
{
	*this = obj;
}

template <class T>
C_arreglo <T> C_arreglo<T>::objeto ( )
{
	return *this;
}


template <class T>
void  C_arreglo<T>::tamano(int val)
{
	_tam = val;
}

template <class T>
int  C_arreglo<T>::tamano ()
{
	return _tam;
}