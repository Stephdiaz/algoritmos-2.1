#include "StdAfx.h"
#include "INTERFAZ.h"


INTERFAZ::INTERFAZ(void)
{
}
