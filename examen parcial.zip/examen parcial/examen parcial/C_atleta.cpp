#include "StdAfx.h"
#include "C_atleta.h"


C_atleta::C_atleta(void)
{
}
