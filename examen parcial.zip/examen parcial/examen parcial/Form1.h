#pragma once
#include "C_arreglo.h"
#include "INTERFAZ.h"
#include "C_atleta.h"
#include "C_deporte.h"
#include "C_inspeccion.h"
#include "C_medicamento.h"
namespace examenparcial {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  g_deporte;
	protected: 
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  Nombre;
	private: System::Windows::Forms::Button^  b1_deporte;
	private: System::Windows::Forms::TextBox^  t_Deporte;

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->g_deporte = (gcnew System::Windows::Forms::DataGridView());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->t_Deporte = (gcnew System::Windows::Forms::TextBox());
			this->b1_deporte = (gcnew System::Windows::Forms::Button());
			this->Nombre = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->g_deporte))->BeginInit();
			this->groupBox1->SuspendLayout();
			this->SuspendLayout();
			// 
			// g_deporte
			// 
			this->g_deporte->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->g_deporte->Location = System::Drawing::Point(18, 19);
			this->g_deporte->Name = L"g_deporte";
			this->g_deporte->Size = System::Drawing::Size(452, 73);
			this->g_deporte->TabIndex = 0;
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Controls->Add(this->Nombre);
			this->groupBox1->Controls->Add(this->b1_deporte);
			this->groupBox1->Controls->Add(this->t_Deporte);
			this->groupBox1->Controls->Add(this->g_deporte);
			this->groupBox1->Location = System::Drawing::Point(12, 12);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(594, 203);
			this->groupBox1->TabIndex = 1;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Deporte";
			// 
			// t_Deporte
			// 
			this->t_Deporte->Location = System::Drawing::Point(476, 35);
			this->t_Deporte->Name = L"t_Deporte";
			this->t_Deporte->Size = System::Drawing::Size(100, 20);
			this->t_Deporte->TabIndex = 1;
			// 
			// b1_deporte
			// 
			this->b1_deporte->Location = System::Drawing::Point(501, 61);
			this->b1_deporte->Name = L"b1_deporte";
			this->b1_deporte->Size = System::Drawing::Size(75, 23);
			this->b1_deporte->TabIndex = 2;
			this->b1_deporte->Text = L"New";
			this->b1_deporte->UseVisualStyleBackColor = true;
			// 
			// Nombre
			// 
			this->Nombre->AutoSize = true;
			this->Nombre->Location = System::Drawing::Point(473, 19);
			this->Nombre->Name = L"Nombre";
			this->Nombre->Size = System::Drawing::Size(44, 13);
			this->Nombre->TabIndex = 3;
			this->Nombre->Text = L"Nombre";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(501, 91);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 4;
			this->button1->Text = L"Insertar";
			this->button1->UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(790, 329);
			this->Controls->Add(this->groupBox1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->g_deporte))->EndInit();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	};
}

