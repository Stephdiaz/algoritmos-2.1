#include "StdAfx.h"
#include "C_deporte.h"


C_deporte::C_deporte(void)
{
}
