#pragma once
#include <iostream>
using namespace std;

 class C_medicamento
{
private:
	string _cod;
	string _nombre;
	string _descripcion;
	bool _nocivo;
public:
	C_medicamento(void);

	void codigo (string val);
	string codigo ();

	void nombre (string val);
	string nombre ();

	void descripcion (string val);
	string descripcion ();

	void nocivo(bool val);
	bool nocivo();
};

	C_medicamento::C_medicamento(void)
	 {
		 	_cod = "";
			 _nombre = "";
			 _descripcion = "";
	 }


	void C_medicamento::codigo (string val)
	{
		_cod = val;
	}
	string C_medicamento::codigo ()
	{
		return _cod;
	}


	void C_medicamento::nombre (string val)
	{
		_nombre = val;
	}
	string C_medicamento::nombre ()
	{
		return _nombre;
	}

	void C_medicamento::descripcion (string val)
	{
		_descripcion = val;
	}
	string C_medicamento::descripcion ()
	{
		return _descripcion;
	}

	void  C_medicamento::nocivo(bool val)
	{
		_nocivo = val;
	}
	bool  C_medicamento::nocivo()
	{
		return _nocivo;
	}

