#pragma once
ref class C_medicamento
{
public:
	C_medicamento(void);
};

