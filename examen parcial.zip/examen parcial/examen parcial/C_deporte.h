#pragma once
#include <iostream>
using namespace std;
class C_deporte
{
private:
	string _nombre;
public:
	C_deporte();

	void deporte (string val);
	string deporte ();

};
	C_deporte::C_deporte()
	{

	}

	void C_deporte::deporte (string val)
	{
		_nombre=val;
	}

	string C_deporte::deporte ()
	{
		return _nombre;
	}

