#pragma once
#include "AUTOMOVIL.h"
using namespace std;

class NISANsub: public AUTOMOVIL
{
public:
	NISANsub(void);
	string fasiendo()
	{
		asiento=5;
		return 0;
	}
	string ftipo()
	{
		tipo=2020;
		return 0;
	}
	string fclase()
	{
		clase= "camioneta";
		return 0;
	}
};

