#include "StdAfx.h"
#include "BMWsub.h"


BMWsub::BMWsub(void)
{
}
