#pragma once
#include <string>
#include <iostream>
using namespace std;
 class transporte
{
public:
	string tipo;
	transporte()
	{
		
	}
};

