#include "StdAfx.h"
#include "AUTOMOVIL.h"


AUTOMOVIL::AUTOMOVIL(void)
{
}
