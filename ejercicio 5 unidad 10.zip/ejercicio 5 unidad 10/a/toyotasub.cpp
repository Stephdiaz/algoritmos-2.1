#include "StdAfx.h"
#include "toyotasub.h"


toyotasub::toyotasub(void)
{
}
