#pragma once
#include <string>
#include <iostream>
using namespace std;
 class comodidad
{
public:
	string asiento;
	comodidad( )
	{
		
	}
};

