#include <string>
#include <iostream>
#include "comodidad.h"
#include "transporte.h"
#include "status.h"
using namespace std;
#pragma once
 class AUTOMOVIL: public comodidad, public transporte, public status
{
public:
	AUTOMOVIL(void);
	virtual string fasiendo()=0;
	virtual string ftipo()=0;
	virtual string fclase()=0;
};

