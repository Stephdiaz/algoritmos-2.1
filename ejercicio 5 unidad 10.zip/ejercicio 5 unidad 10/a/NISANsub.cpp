#include "StdAfx.h"
#include "NISANsub.h"


NISANsub::NISANsub(void)
{
}
