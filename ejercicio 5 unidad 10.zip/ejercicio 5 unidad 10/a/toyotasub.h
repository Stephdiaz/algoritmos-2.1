#pragma once
#include "AUTOMOVIL.h"
using namespace std;

class toyotasub: public AUTOMOVIL
{
public:
	toyotasub(void);
	string fasiendo()
	{
		asiento=6;
		return 0;
	}
	string ftipo()
	{
		tipo=2000;
		return 0;
	}
	string fclase()
	{
		clase= "bus";
		return 0;
	}
};


