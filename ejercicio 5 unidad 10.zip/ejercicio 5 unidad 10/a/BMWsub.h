#pragma once
#include "AUTOMOVIL.h"
using namespace std;

class BMWsub: public AUTOMOVIL
{
public:
	BMWsub(void);
	string fasiendo()
	{
		asiento=4;
		return 0;
	}
	string ftipo()
	{
		tipo=2010;
		return 0;
	}
	string fclase()
	{
		clase= "vagoneta";
		return 0;
	}
};

