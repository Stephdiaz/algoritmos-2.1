#pragma once
#include <iostream>
using namespace std;

class MEDICAMENTO
{
private:
	string _cod;
	string _nombre;
	string _descripcion;
	bool _nocivo;
public:
	MEDICAMENTO(void);

	void codigo (string val);
	string codigo ();

	void nombre (string val);
	string nombre ();

	void descripcion (string val);
	string descripcion ();

	void nocivo(bool val);
	bool nocivo();
};
/*
	MEDICAMENTO::MEDICAMENTO(void)
	 {
		 	_cod = "";
			 _nombre = "";
			 _descripcion = "";
	 }


	void MEDICAMENTO::codigo (string val)
	{
		_cod = val;
	}
	string MEDICAMENTO::codigo ()
	{
		return _cod;
	}


	void MEDICAMENTO::nombre (string val)
	{
		_nombre = val;
	}
	string MEDICAMENTO::nombre ()
	{
		return _nombre;
	}

	void MEDICAMENTO::descripcion (string val)
	{
		_descripcion = val;
	}
	string MEDICAMENTO::descripcion ()
	{
		return _descripcion;
	}

	void  MEDICAMENTO::nocivo(bool val)
	{
		_nocivo = val;
	}
	bool  MEDICAMENTO::nocivo()
	{
		return _nocivo;
	}

	*/