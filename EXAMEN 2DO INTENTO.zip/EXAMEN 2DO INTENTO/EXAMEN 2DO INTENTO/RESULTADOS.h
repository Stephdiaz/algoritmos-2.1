#pragma once
#include <iostream>

class RESULTADOS
{
public:
	RESULTADOS(void);
};


 RESULTADOS::RESULTADOS () 
 {

 }