#include "StdAfx.h"
#include "DEPORTE_ATLETA.h"


DEPORTE_ATLETA::DEPORTE_ATLETA(void)
{
}
