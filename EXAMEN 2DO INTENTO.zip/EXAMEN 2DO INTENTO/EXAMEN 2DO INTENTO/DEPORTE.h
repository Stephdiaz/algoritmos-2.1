#pragma once
#include <iostream>

using namespace std;

class DEPORTE
{
private:
	string _nombre;
public:
	DEPORTE();

	void deporte (string val);
	string deporte ();

};/*
	DEPORTE::DEPORTE()
	{

	}

	void DEPORTE::deporte (string val)
	{
		_nombre=val;
	}

	string DEPORTE::deporte ()
	{
		return _nombre;
	}

	*/