#include "StdAfx.h"
#include "ATLETA.h"


ATLETA::ATLETA(void)
{
}
