#pragma once
#include <iostream>
 class INTERFAZ
{
public:
	INTERFAZ(void);
};

 INTERFAZ::INTERFAZ () 
 {

 }