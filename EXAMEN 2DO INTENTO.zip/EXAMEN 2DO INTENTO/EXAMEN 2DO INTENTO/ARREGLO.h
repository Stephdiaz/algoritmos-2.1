#pragma once
#include <iostream>
const int MAX = 20;
template <class T>

class ARREGLO
{
private:

	T vector [MAX];
	int _tam;

public:
	ARREGLO(void);

	void datos (int pos, T val);
	T datos(int);

	void objeto (ARREGLO<T> obj );
	ARREGLO <T> objeto ();

	void tamano(int val);
	int tamano ();
};

/*
template <class T>
ARREGLO<T>::ARREGLO()
{
	_tam=0;
}


template <class T>
void ARREGLO<T>::datos (int pos, T val)
{
	vector[pos] = val;
}

template <class T>
T ARREGLO<T>::datos  (int pos)
{
 return vector[pos];
}



template <class T>
void ARREGLO<T>::objeto (ARREGLO<T>  obj)
{
	*this = obj;
}

template <class T>
ARREGLO <T> ARREGLO<T>::objeto ( )
{
	return *this;
}


template <class T>
void  ARREGLO<T>::tamano(int val)
{
	_tam = val;
}

template <class T>
int  ARREGLO<T>::tamano ()
{
	return _tam;
}*/