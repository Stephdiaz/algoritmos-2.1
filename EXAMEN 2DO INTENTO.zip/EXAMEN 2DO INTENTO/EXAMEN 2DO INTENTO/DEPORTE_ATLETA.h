#pragma once
#include <iostream>
#include "DEPORTE.h"
#include "ATLETA.h"

class DEPORTE_ATLETA public DEPORTE public ATLETA
{
public:
	DEPORTE_ATLETA(void);
};
	DEPORTE_ATLETA::DEPORTE_ATLETA()
	{

	}
