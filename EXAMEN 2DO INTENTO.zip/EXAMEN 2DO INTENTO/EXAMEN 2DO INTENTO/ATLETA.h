#pragma once

#include <iostream>
using namespace std;

class ATLETA 
{
private:
	string _cod;
	string _nombre;

	
public:
	ATLETA(void);

	void nombre (string val);
	string nombre ();

	void codigo (string val);
	string codigo ();

};/*

	ATLETA::ATLETA()
	{
		_nombre = " ";
		_cod= " ";
		
	}


	void ATLETA::nombre (string val)
	{
		_nombre = val;
	}
	string ATLETA::nombre ()
	{
		return _nombre;
	}



	void ATLETA::codigo (string val)
	{
		_cod = val;
	}

	string ATLETA::codigo ()
	{
		return _cod;
	}*/





