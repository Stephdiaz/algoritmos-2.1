#include "StdAfx.h"
#include "RESULTADOS.h"


RESULTADOS::RESULTADOS(void)
{
}
