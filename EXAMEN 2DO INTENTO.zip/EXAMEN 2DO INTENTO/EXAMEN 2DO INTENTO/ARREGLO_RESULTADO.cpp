#include "StdAfx.h"
#include "ARREGLO_RESULTADO.h"


ARREGLO_RESULTADO::ARREGLO_RESULTADO(void)
{
}
