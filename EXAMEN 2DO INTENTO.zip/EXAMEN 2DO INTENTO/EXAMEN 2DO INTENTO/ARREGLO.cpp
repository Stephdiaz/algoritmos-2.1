#include "StdAfx.h"
#include "ARREGLO.h"


ARREGLO::ARREGLO(void)
{
}
