#pragma once
#include"ARREGLO.h"
#include "RESULTADOS.h"

 class ARREGLO_RESULTADO public ARREGLO<RESULTADO>;
{
public:
	ARREGLO_RESULTADO(void);
};

ARREGLO_RESULTADO::ARREGLO_RESULTADO()
{

}
