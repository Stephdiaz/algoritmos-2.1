#pragma once
#include <iostream>
#include"ARREGLO_RESULTADO.h"
#include "ARREGLO_DEPORTE_ATLETA.h"

 class PROGRAMA public ARREFGLO_RESULTADO public ARREGLO_DEPORTE_ATLETA
{
private:
	ARREFGLO_RESULTADO _Resultado;
	ARREGLO_DEPORTE_ATLETA _atleta;

public:
	PROGRAMA(void);
	void lista_atletas (int pos, ATLETA val);
	ATLETA lista_atletas (int pos);

	void lista_resultado (int pos, RESULTADO val);
	RESULTADO lista_resultado (int pos);

};

 PROGRAMA::PROGRAMA () 
 {

 }
 /*
 	void PROGRAMA::lista_resultado (int pos, RESULTADO val)
	{
		_resultado.datos (pos,val);
	}
	ATLETA PROGRAMA::lista_resultado (int pos)

	{
		return _resultado.datos (pos);
	}
	*/

	void PROGRAMA::lista_atletas (int pos, ATLETA val)
	{
		_atleta.datos (pos,val);
	}
	ATLETA PROGRAMA::lista_atletas (int pos)

	{
		return _atleta.datos (pos);
	}