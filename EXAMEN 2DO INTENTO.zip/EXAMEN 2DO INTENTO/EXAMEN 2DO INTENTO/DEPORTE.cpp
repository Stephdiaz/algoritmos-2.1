#include "StdAfx.h"
#include "DEPORTE.h"


DEPORTE::DEPORTE(void)
{
}
