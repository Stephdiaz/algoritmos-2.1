#pragma once
#include <iostream>
#include "DEPORTE_ATLETA.h"

 class PRUEBA public: DEPORTE_ATLETA
{
public:
	PRUEBA(void);
};

 
 PRUEBA::PRUEBA () 
 {

 }