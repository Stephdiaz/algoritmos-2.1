// stdafx.cpp: archivo de c�digo fuente que contiene s�lo las inclusiones est�ndar
// EXAMEN 2DO INTENTO.pch ser� el encabezado precompilado
// stdafx.obj contiene la informaci�n de tipos precompilada

#include "stdafx.h"


